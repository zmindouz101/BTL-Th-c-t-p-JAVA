package zSERVER;

/**
 *
 * @author Hoàng Ngọc Long
 */
public class zProgram {
    public static void main(String[] args) {
        new Thread( new FrmServerGUI()).start();
    }
}
