package PACKAGES;

/**
 *
 * @Hoàng Ngọc Long 64121
 */
public class PacketChat extends PacketTin{
    public static final String ID = "chat";
    public PacketChat() {
        setId(ID);
    }
}
