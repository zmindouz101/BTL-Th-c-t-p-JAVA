package PACKAGES;

/**
 *
 * @@Hoàng Ngọc Long 
 */
public class PacketThongDiep extends PacketTin {
    public static final String ID = "thongdiep";
    public PacketThongDiep() {
        setId(ID);
    }
}
