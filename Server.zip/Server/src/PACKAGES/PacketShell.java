package PACKAGES;

/**
 *
 * @@Hoàng Ngọc Long 
 */
public class PacketShell extends PacketTin{
    public static final String ID = "shell";
    public PacketShell() {
        setId(ID);
    }
}
